-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Client :  localhost:8889
-- Généré le :  Ven 06 Juin 2014 à 05:06
-- Version du serveur :  5.5.34
-- Version de PHP :  5.5.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `snippets`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(254) NOT NULL,
  `title` varchar(254) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` (`id`, `slug`, `title`) VALUES
(1, 'html', 'HTML'),
(2, 'css', 'CSS'),
(3, 'javascript', 'JavaScript'),
(4, 'php', 'PHP'),
(5, 'nodejs', 'NodeJS');

-- --------------------------------------------------------

--
-- Structure de la table `snippets`
--

CREATE TABLE `snippets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(254) NOT NULL,
  `content` text NOT NULL,
  `description` text NOT NULL,
  `username` varchar(254) NOT NULL,
  `parent` int(254) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `snippets`
--

INSERT INTO `snippets` (`id`, `id_category`, `title`, `content`, `description`, `username`, `parent`) VALUES
(2, 3, 'While - Loop', 'while (1) {\r\n	console.log(''Infinite Loop'');\r\n}', 'How to make a loop in JavaScript.', 'Hugo', 0),
(3, 3, 'While - Loop', 'var i = 0;\r\nwhile (i < 10) {\r\n	console.log(''No more Infinite Loop'');\r\n  	i++;\r\n}', 'How to make a true loop in JavaScript.', 'Justine', 2);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(254) NOT NULL,
  `mail` varchar(254) NOT NULL,
  `password` varchar(254) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `username`, `mail`, `password`, `admin`) VALUES
(1, 'Hugo', 'hugo@hugo.com', 'a8c158f31247f9bfce74b243525efaa1203e023cc0add6fe112d86b25c53ec1356f4425728c638df51f1a89abbb31d78cd885fd751726f6773cc4a47ee8cf90e', 0),
(2, 'Justine', 'justine@justine.com', 'a8c158f31247f9bfce74b243525efaa1203e023cc0add6fe112d86b25c53ec1356f4425728c638df51f1a89abbb31d78cd885fd751726f6773cc4a47ee8cf90e', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
